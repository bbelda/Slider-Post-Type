<?php
add_shortcode('slider_post_type_shortcode', 'show_custom_post_type');
function show_custom_post_type($atts) {
    ob_start();
    $post_id = $atts['id'];
    $args = array( 'post_type' => 'slider_post_type' , 'p' => $post_id );
    $the_query = new WP_Query( $args ); 
    
    while ( $the_query->have_posts() ) { $the_query->the_post();
  ?>
  <div class="slider-post-type">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="slider-recent-subheading">
          <?php 
            $items = carbon_get_the_post_meta('custom_slider_items'); 
            $counter=1; 
          ?>
            <?php foreach($items as $item): ?>
              <?php if($counter == 1) {  ?>
                <h6>
                  <?php echo $item['custom_slider_items_subhead']; ?>
                </h6>
              <?php } ?>
          <?php $counter++; endforeach; ?>
          </div>
        </div>
      </div>
      <?php 
        $items = carbon_get_the_post_meta('custom_slider_items'); 
        $counter = 1;
      ?>
      <?php foreach($items as $item): ?>
        <?php if($counter == 1) { ?>
          <div class="slider-recent-container" id="<?php echo sanitize_title($item['custom_slider_items_heading']); ?>">
            <div class="slider-recent-image">
              <img src="<?php echo $item['custom_slider_items_image'] ?>"> 
            </div>
            <div class="slider-recent-content">
              <h3><?php echo $item['custom_slider_items_heading'] ?></h3>
              <?php echo wpautop($item['custom_slider_items_content']) ?>
            </div>
          </div>
        <?php } ?>
      <?php $counter++; endforeach; ?>
      <div class="slider-container">
        <div class="row">
          <div class="col-md-12">
            <h6>Select a Case Study</h6>
          </div>
        </div>
        <div class="slider-single-carousel owl-carousel owl-loaded">
          <?php 
            $items = carbon_get_the_post_meta('custom_slider_items'); 
            $counter = 1;
          ?>
            <?php foreach($items as $item): ?>
              <div class="slider-single-item">
                <div class="slider-single-image">
                  <img src="<?php echo $item['custom_slider_items_image'] ?>">
                </div>
                <div class="slider-single-content">
                  <h6><?php echo $item['custom_slider_items_subhead']; ?></h6>
                  <h3><?php echo $item['custom_slider_items_heading'] ?></h3>
                  <div class="content-details hidden">
                    <?php echo wpautop($item['custom_slider_items_content']) ?>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
<?php } ?>
  
<?php

    wp_reset_postdata();
    $content = ob_get_clean();
    return $content;
}


function crunchify_reorder_columns($columns) {
    $crunchify_columns = array();
    $title = 'author'; 
    foreach($columns as $key => $value) {
      if ($key==$title){
          $crunchify_columns['slider_post_type_shortcode'] = '';   // Move date column before title column
          $crunchify_columns['date'] = '';   // Move date column before title column
        // $crunchify_columns['author'] = '';   // Move author column before title column
      }
        $crunchify_columns[$key] = $value;
    }
    return $crunchify_columns;
  }
  add_filter('manage_posts_columns', 'crunchify_reorder_columns');

add_filter( 'manage_slider_post_type_posts_columns', 'set_custom_edit_slider_post_type_columns' );
function set_custom_edit_slider_post_type_columns($columns) {
    $columns['slider_post_type_shortcode'] = __( 'Shortcode');

    return $columns;
}
// Add the data to the custom columns for the slider_post_type post type:
add_action( 'manage_slider_post_type_posts_custom_column' , 'custom_slider_post_type_column', 10, 2 );
function custom_slider_post_type_column( $column, $post_id ) {
    switch ( $column ) {
        
        case 'slider_post_type_shortcode' :
            $shortcode_name = 'slider_post_type_shortcode';
            echo '['.$shortcode_name.' id="'.$post_id.'"]';
            break;
        default : 
            echo $column;
        break;
    }
}



