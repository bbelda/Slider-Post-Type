<<<<<<< HEAD
# Slider Post Types

A plugin where you can create slider post type with preview post.
=======
# custom-tabs
>>>>>>> de616595e4d17db7e1dfb978ad3d179721abe25a

Install the carbon fields plugin

Link: https://carbonfields.net/zip/latest/

