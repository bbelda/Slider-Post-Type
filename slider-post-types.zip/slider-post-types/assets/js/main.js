(function ($) {
  $(document).ready(function () {
    case_study_carousel();
  });
  function case_study_carousel() {
    var owl = $(".slider-single-carousel.owl-carousel");
    owl.owlCarousel({
      nav: true,
      loop: false,
      dots: false,
      touchDrag: false,
      mouseDrag: false,
      navText: ["", ""],
      margin: 37,
      items: 3,
      responsive: {
        0: {
          items: 1,
          margin: 30,
          touchDrag: true,
          mouseDrag: true,
          stagePadding: 25,
          loop: true,
          nav: false,
          dots: false,
        },
        992: {
          items: 2,
        },
        1200: {
          items: 3,
        },
      },
    });

    $(".slider-single-item .button.button-borderless").on("click", function (
      event
    ) {
      event.preventDefault();
      owl.trigger("owl.goTo", 2);
    });
    // Click event in desktop carousel
    $(".slider-single-item").on("click", function () {
      var recent_item = $(".slider-recent-container");
      var category = $(".slider-recent-subheading");
      var image = $(this).find(".slider-single-image img").attr("src");
      var category_text = $(this).find(".slider-single-content h6").html();
      var heading = $(this).find(".slider-single-content h3").html();
      var content = $(this)
        .find(".slider-single-content .content-details")
        .html();

      var idName = heading.toLowerCase().replace(/\s+/g, "-");
      category.find("h6:not(.select-title)").html(category_text);
      recent_item.find(".slider-recent-image img").attr("src", image);
      recent_item
        .find(".slider-recent-content")
        .html("<h3>" + heading + "</h3>" + content);
      // recent_item.find(".slider-recent-content").html(content);
      recent_item.attr("id", idName);

      category.fadeOut(100);
      category.fadeIn(200);

      recent_item.fadeOut(100);
      recent_item.fadeIn(200);

      if (!$(this).parent().hasClass("active")) {
        if (
          !$(this).parent().prev().hasClass("active") &&
          $(this).parent().next().hasClass("active")
        ) {
          owl.trigger("prev.owl.carousel");
        } else if (
          $(this).parent().prev().hasClass("active") &&
          !$(this).parent().next().hasClass("active")
        ) {
          owl.trigger("next.owl.carousel");
        }
      } else {
        if (
          $(this).parent().prev().hasClass("active") &&
          !$(this).parent().next().hasClass("active")
        ) {
          owl.trigger("next.owl.carousel");
        }
      }

      if ($(window).width() >= 992) {
        $("html,body").animate({
          scrollTop: $(".case-study-gallery").offset().top - 160,
        });
      } else {
        $("html,body").animate({
          scrollTop: $(".case-study-gallery").offset().top - 15,
        });
      }
    });

    // mobile touch drag event
    if ($(window).width() <= 992) {
      var max = -1;
      $(".slider-single-carousel .owl-item").each(function () {
        var h = $(this)
          .find(".slider-single-item .slider-single-content h6")
          .height();
        max = h > max ? h : max;
      });
      $(
        ".slider-single-carousel .slider-single-item .slider-single-content h6"
      ).height(max);
      // console.log("mobile");
      // console.log(max);
      owl.on("change.owl.carousel", function (event) {
        // console.log("current: ", event.relatedTarget.current());
        // console.log(owl.find(".owl-item").eq(event.relatedTarget.current()));
        setTimeout(function () {
          var recent_item = $(".slider-recent-container");
          var category = $(".slider-recent-subheading");
          var current = owl.find(".owl-item.active");
          var image = current.find(".slider-single-image img").attr("src");
          var category_text = current.find(".slider-single-content h6").html();
          var heading = current.find(".slider-single-content h3").html();
          var content = current
            .find(".slider-single-content .content-details p")
            .html();

          var idName = heading.toLowerCase().replace(/\s+/g, "-");

          category.find("h6:not(.select-title)").html(category_text);
          recent_item.find(".slider-recent-image img").attr("src", image);
          recent_item.find(".slider-recent-content h3").html(heading);
          recent_item.find(".slider-recent-content p").html(content);
          recent_item.attr("id", idName);

          // category.fadeOut(100);
          // category.fadeIn(200);

          // recent_item.fadeOut(100);
          // recent_item.fadeIn(200);
          // console.log(image);
          $("html,body").animate({
            scrollTop: $(".case-study-gallery").offset().top - 15,
          });
        }, 1);
      });
    }
  }
})(jQuery);
